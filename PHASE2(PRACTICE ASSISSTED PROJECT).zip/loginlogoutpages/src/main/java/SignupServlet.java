import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/SignupServlet")
public class SignupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Retrieve the username and password from the form submission
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Validate the username and password (you can customize this part based on your requirements)
        if (username != null && password != null) {
            // Store the user information in a database or any other storage mechanism
            // For simplicity, we will just print the username and password

            out.println("<html>");
            out.println("<head>");
            out.println("<title>Signup Successful</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Signup Successful</h1>");
            out.println("<p>Your account has been created successfully.</p>");
            out.println("<p>Username: " + username + "</p>");
            out.println("<p>Password: " + password + "</p>");
            out.println("<p>Please <a href='login.html'>login</a> to continue.</p>");
            out.println("</body>");
            out.println("</html>");
        } else {
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Signup Failed</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Signup Failed</h1>");
            out.println("<p>Invalid username or password.</p>");
            out.println("<a href='signup.html'>Try Again</a>");
            out.println("</body>");
            out.println("</html>");
        }

        out.close();
    }
}
