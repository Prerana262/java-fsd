import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/SessionServlet")
public class SessionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // Retrieve the session object
        HttpSession session = request.getSession();
        
        // Check if it's a new session
        boolean isNewSession = session.isNew();
        
        // Get the session ID
        String sessionId = session.getId();
        
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Session Tracking Demo</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Session Tracking Demo</h1>");
        
        if (isNewSession) {
            out.println("New session created. Session ID: " + sessionId);
        } else {
            out.println("Existing session detected. Session ID: " + sessionId);
        }
        
        out.println("</body>");
        out.println("</html>");
        
        out.close();
    }
}
