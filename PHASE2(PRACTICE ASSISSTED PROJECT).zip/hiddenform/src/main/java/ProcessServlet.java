import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ProcessServlet")
public class ProcessServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // Retrieve the session ID from the hidden form field
        String sessionId = request.getParameter("sessionId");
        
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Process Servlet</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Process Servlet</h1>");
        out.println("<p>Session ID: " + sessionId + "</p>");
        out.println("</body>");
        out.println("</html>");
        
        out.close();
    }
}
