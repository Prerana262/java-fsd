import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/SessionServlet")
public class SessionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // Retrieve the session object
        HttpSession session = request.getSession();
        
        // Check if the session already has a cookie with a unique session ID
        String sessionId = session.getId();
        Cookie[] cookies = request.getCookies();
        boolean isNewSession = true;
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("sessionId") && cookie.getValue().equals(sessionId)) {
                    isNewSession = false;
                    break;
                }
            }
        }
        
        // Set a new cookie with the session ID if it's a new session
        if (isNewSession) {
            Cookie sessionCookie = new Cookie("sessionId", sessionId);
            sessionCookie.setMaxAge(60 * 60); // Cookie expires in 1 hour
            response.addCookie(sessionCookie);
            out.println("New session created. Session ID: " + sessionId);
        } else {
            out.println("Existing session detected. Session ID: " + sessionId);
        }
        
        // Invalidate the session after 5 minutes for demonstration purposes
        session.setMaxInactiveInterval(5 * 60); // Session expires in 5 minutes
        session.invalidate();
        
        out.close();
    }
}
